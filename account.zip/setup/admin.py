from django.contrib import admin

from .models import *

admin.site.register(Supplier)
admin.site.register(Brand)
admin.site.register(Market)
admin.site.register(Dsr)
admin.site.register(Bank)
admin.site.register(Product)
admin.site.register(Doprice)
admin.site.register(Sellprice)
admin.site.register(Salesmanager)
admin.site.register(Discountsetup)
admin.site.register(Collectionsetup)
admin.site.register(GramSetup)



