from django.contrib import admin
from .models import *

admin.site.register(Lifting)
admin.site.register(Sales)
admin.site.register(Damage)
admin.site.register(BankTransaction)
admin.site.register(SupplierPayment)
admin.site.register(Acdiccount)
admin.site.register(Dailycost)
admin.site.register(CollectionTransaction)
admin.site.register(Assets)

